from flask import Flask
from database.db import get_setting

app = Flask(__name__)

@app.route("/")
def index():
    return """
    <h1>Discord Bot Panel</h1>
    <p>Status: ONLINE</p>
    """

def run_web():
    app.run(host="0.0.0.0", port=3000)
