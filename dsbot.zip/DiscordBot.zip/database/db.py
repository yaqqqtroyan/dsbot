antinuke = {}
whitelist = {}

def enable(guild_id):
    antinuke[guild_id] = True

def disable(guild_id):
    antinuke[guild_id] = False

def is_enabled(guild_id):
    return antinuke.get(guild_id, False)

def wl_add(guild_id, user_id):
    whitelist.setdefault(guild_id, set()).add(user_id)

def wl_remove(guild_id, user_id):
    whitelist.setdefault(guild_id, set()).discard(user_id)

def is_trusted(guild_id, user_id):
    return user_id in whitelist.get(guild_id, set())
