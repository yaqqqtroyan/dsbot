import discord
from discord.ext import commands
import os
import asyncio
from dotenv import load_dotenv

load_dotenv()

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="h.", intents=intents)

@bot.event
async def on_ready():
    print(f"✅ Бот запущен: {bot.user}")
    await bot.tree.sync()
    print("✅ Slash-команды синхронизированы")

async def load_cogs():
    for file in os.listdir("./cogs"):
        if file.endswith(".py"):
            await bot.load_extension(f"cogs.{file[:-3]}")
            print(f"🔹 Загружен cog: {file}")

async def main():
    async with bot:
        await load_cogs()
        await bot.start(os.getenv("TOKEN"))

asyncio.run(main())
