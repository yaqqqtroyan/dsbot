import discord, time
from discord.ext import commands
from database.db import get_setting, wl_check

class AntiRaid(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.actions = {}

    async def punish(self, guild, user):
        try:
            await guild.ban(user, reason="AntiRaid")
        except:
            pass

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        if get_setting(member.guild.id, "antinuke") != "on":
            return

        async for log in member.guild.audit_logs(limit=1):
            user = log.user
            if user.id == member.guild.owner_id:
                return
            if wl_check(member.guild.id, user.id):
                return

            now = time.time()
            acts = self.actions.get(user.id, [])
            acts = [t for t in acts if now - t < 10]
            acts.append(now)
            self.actions[user.id] = acts

            if len(acts) >= 3:
                await self.punish(member.guild, user)

async def setup(bot):
    await bot.add_cog(AntiRaid(bot))
