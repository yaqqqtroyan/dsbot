import discord
from discord.ext import commands
from discord import app_commands
from database.db import set_setting

class Setup(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="setup", description="Быстрая настройка сервера")
    @app_commands.checks.has_permissions(administrator=True)
    async def setup(
        self,
        interaction: discord.Interaction,
        logs: discord.TextChannel,
        welcome: discord.TextChannel,
        autorole: discord.Role
    ):
        guild_id = interaction.guild.id

        set_setting(guild_id, "logs", logs.id)
        set_setting(guild_id, "welcome", welcome.id)
        set_setting(guild_id, "autorole", autorole.id)
        set_setting(guild_id, "antinuke", "on")
        set_setting(guild_id, "antispam", "on")

        await interaction.response.send_message(
            "✅ **Сервер успешно настроен!**\n\n"
            f"📄 Логи: {logs.mention}\n"
            f"👋 Welcome: {welcome.mention}\n"
            f"🎭 Авто-роль: {autorole.mention}\n"
            "🛡 AntiNuke: ON\n"
            "🧠 AntiSpam: ON",
            ephemeral=True
        )

async def setup(bot):
    await bot.add_cog(Setup(bot))
