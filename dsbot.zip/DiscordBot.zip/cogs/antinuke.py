import discord
from discord.ext import commands
from database.db import get_setting, wl_check

class AntiNuke(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def punish(self, guild, user, reason):
        try:
            await guild.ban(user, reason=reason)
        except:
            pass

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        if get_setting(channel.guild.id, "antinuke") != "on":
            return

        async for log in channel.guild.audit_logs(
            limit=1,
            action=discord.AuditLogAction.channel_create
        ):
            if log.user.id == channel.guild.owner_id:
                return
            if wl_check(channel.guild.id, log.user.id):
                return

            await channel.delete()
            await self.punish(channel.guild, log.user, "AntiNuke: Channel Create")

    @commands.Cog.listener()
    async def on_role_create(self, role):
        if get_setting(role.guild.id, "antinuke") != "on":
            return

        async for log in role.guild.audit_logs(
            limit=1,
            action=discord.AuditLogAction.role_create
        ):
            if wl_check(role.guild.id, log.user.id):
                return

            await role.delete()
            await self.punish(role.guild, log.user, "AntiNuke: Role Create")

async def setup(bot):
    await bot.add_cog(AntiNuke(bot))
