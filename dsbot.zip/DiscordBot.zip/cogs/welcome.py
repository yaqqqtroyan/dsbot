import discord
from discord.ext import commands
from database.db import get_setting

class Welcome(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member):
        channel_id = get_setting(member.guild.id, "welcome")
        if not channel_id:
            return

        channel = member.guild.get_channel(int(channel_id))
        if channel:
            await channel.send(f"👋 Добро пожаловать, {member.mention}!")

async def setup(bot):
    await bot.add_cog(Welcome(bot))
