import discord
from discord.ext import commands
from discord import app_commands
from database.db import set_setting

class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="enable", description="Включить анти-краш")
    async def enable(self, interaction: discord.Interaction):
        set_setting(interaction.guild.id, "antinuke", "on")
        await interaction.response.send_message("🛡 Анти-краш включен", ephemeral=True)

    @app_commands.command(name="disable", description="Выключить анти-краш")
    async def disable(self, interaction: discord.Interaction):
        set_setting(interaction.guild.id, "antinuke", "off")
        await interaction.response.send_message("❌ Анти-краш выключен", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Utility(bot))
