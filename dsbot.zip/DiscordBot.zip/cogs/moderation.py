import discord
from discord.ext import commands
from discord import app_commands

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="ban", description="Забанить пользователя")
    @app_commands.checks.has_permissions(ban_members=True)
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = "Без причины"):
        await member.ban(reason=reason)
        await interaction.response.send_message(f"🔨 {member} забанен\nПричина: {reason}", ephemeral=True)

    @app_commands.command(name="kick", description="Кикнуть пользователя")
    @app_commands.checks.has_permissions(kick_members=True)
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "Без причины"):
        await member.kick(reason=reason)
        await interaction.response.send_message(f"👢 {member} кикнут", ephemeral=True)

    @app_commands.command(name="nick", description="Сменить ник")
    @app_commands.checks.has_permissions(manage_nicknames=True)
    async def nick(self, interaction: discord.Interaction, member: discord.Member, nickname: str):
        await member.edit(nick=nickname)
        await interaction.response.send_message("✅ Ник изменён", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Moderation(bot))
