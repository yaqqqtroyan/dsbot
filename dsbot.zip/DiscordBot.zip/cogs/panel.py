import discord
from discord.ext import commands
from discord import app_commands

PANEL_URL = "https://your-replit-name.replit.app"

class Panel(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="panel", description="Открыть панель управления")
    async def panel(self, interaction: discord.Interaction):
        await interaction.response.send_message(
            f"🌐 Панель управления:\n{PANEL_URL}",
            ephemeral=True
        )

async def setup(bot):
    await bot.add_cog(Panel(bot))
