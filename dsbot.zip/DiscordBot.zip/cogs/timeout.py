import discord
from discord.ext import commands
from discord import app_commands

class Timeout(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="mute", description="Замьютить пользователя")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def mute(self, interaction: discord.Interaction, member: discord.Member, minutes: int):
        until = discord.utils.utcnow() + discord.timedelta(minutes=minutes)
        await member.timeout(until)
        await interaction.response.send_message(
            f"🔇 {member.mention} замьючен на {minutes} минут",
            ephemeral=True
        )

    @app_commands.command(name="unmute", description="Снять мут")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def unmute(self, interaction: discord.Interaction, member: discord.Member):
        await member.timeout(None)
        await interaction.response.send_message("✅ Мут снят", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Timeout(bot))
