import discord
from discord.ext import commands
from discord import app_commands
from database.db import wl_add, wl_remove, wl_list

class WhiteList(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="wl_add", description="Добавить пользователя в белый список")
    @app_commands.checks.has_permissions(administrator=True)
    async def add(self, interaction: discord.Interaction, user: discord.User):
        wl_add(interaction.guild.id, user.id)
        await interaction.response.send_message(f"✅ {user.mention} добавлен в WL", ephemeral=True)

    @app_commands.command(name="wl_remove", description="Убрать пользователя из белого списка")
    @app_commands.checks.has_permissions(administrator=True)
    async def remove(self, interaction: discord.Interaction, user: discord.User):
        wl_remove(interaction.guild.id, user.id)
        await interaction.response.send_message(f"❌ {user.mention} удалён из WL", ephemeral=True)

    @app_commands.command(name="wl_list", description="Показать белый список")
    async def list(self, interaction: discord.Interaction):
        users = wl_list(interaction.guild.id)
        text = "\n".join([f"<@{u}>" for u in users]) or "Пусто"
        await interaction.response.send_message(text, ephemeral=True)

async def setup(bot):
    await bot.add_cog(WhiteList(bot))
