import discord
from discord.ext import commands
from database.db import get_setting

class Logs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def send(self, guild, embed):
        cid = get_setting(guild.id, "logs")
        if not cid:
            return
        ch = guild.get_channel(int(cid))
        if ch:
            await ch.send(embed=embed)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        embed = discord.Embed(
            title="👋 Новый участник",
            description=f"{member.mention} зашёл на сервер",
            color=discord.Color.green()
        )
        await self.send(member.guild, embed)

    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        embed = discord.Embed(
            title="🔨 Бан",
            description=f"{user} был забанен",
            color=discord.Color.red()
        )
        await self.send(guild, embed)

async def setup(bot):
    await bot.add_cog(Logs(bot))
