import sqlite3

conn = sqlite3.connect("database/bot.db")
cur = conn.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS settings (
    guild_id INTEGER,
    key TEXT,
    value TEXT
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS whitelist (
    guild_id INTEGER,
    user_id INTEGER
)
""")

conn.commit()

def set_setting(guild_id, key, value):
    cur.execute("REPLACE INTO settings VALUES (?, ?, ?)", (guild_id, key, value))
    conn.commit()

def get_setting(guild_id, key):
    cur.execute("SELECT value FROM settings WHERE guild_id=? AND key=?", (guild_id, key))
    row = cur.fetchone()
    return row[0] if row else None

def wl_add(guild_id, user_id):
    cur.execute("INSERT INTO whitelist VALUES (?, ?)", (guild_id, user_id))
    conn.commit()

def wl_remove(guild_id, user_id):
    cur.execute("DELETE FROM whitelist WHERE guild_id=? AND user_id=?", (guild_id, user_id))
    conn.commit()

def wl_list(guild_id):
    cur.execute("SELECT user_id FROM whitelist WHERE guild_id=?", (guild_id,))
    return [x[0] for x in cur.fetchall()]

def wl_check(guild_id, user_id):
    cur.execute("SELECT 1 FROM whitelist WHERE guild_id=? AND user_id=?", (guild_id, user_id))
    return cur.fetchone() is not None
