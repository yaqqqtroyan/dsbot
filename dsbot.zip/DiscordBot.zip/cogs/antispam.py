import discord, time
from discord.ext import commands
from database.db import get_setting

class AntiSpam(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.users = {}

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return

        if get_setting(message.guild.id, "antispam") != "on":
            return

        now = time.time()
        user = self.users.get(message.author.id, [])

        user = [t for t in user if now - t < 5]
        user.append(now)
        self.users[message.author.id] = user

        if len(user) >= 5:
            await message.delete()
            await message.author.timeout(
                discord.utils.utcnow() + discord.timedelta(minutes=5)
            )
            await message.channel.send(
                f"🧠 {message.author.mention} замьючен за спам",
                delete_after=5
            )

async def setup(bot):
    await bot.add_cog(AntiSpam(bot))
