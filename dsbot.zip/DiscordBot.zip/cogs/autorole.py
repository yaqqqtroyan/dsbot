import discord
from discord.ext import commands
from discord import app_commands
from database.db import set_setting, get_setting

class AutoRole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member):
        role_id = get_setting(member.guild.id, "autorole")
        if role_id:
            role = member.guild.get_role(int(role_id))
            if role:
                await member.add_roles(role)

    @app_commands.command(name="autorole", description="Установить авто-роль")
    @app_commands.checks.has_permissions(administrator=True)
    async def autorole(self, interaction: discord.Interaction, role: discord.Role):
        set_setting(interaction.guild.id, "autorole", role.id)
        await interaction.response.send_message(f"✅ Авто-роль установлена: {role.mention}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(AutoRole(bot))
